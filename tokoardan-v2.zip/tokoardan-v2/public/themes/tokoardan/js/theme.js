/**
 * TOKOARDAN Theme — Dark Coal Edition
 * ©2025-2026 tokoardan.my.id
 */
(function () {
  'use strict';

  /* ============================================================
     CONFIG
  ============================================================ */
  var CFG = {
    storageKey: 'tkd_logo_url',
    defaultLogo: 'https://i.ibb.co.com/Z604svvV/background-removed-1769186041755.webp',
    siteUrl: 'https://tokoardan.my.id',
    consoleName: 'container-tokoardan~',
    copyrightStart: 2025,
  };

  /* ============================================================
     LOGO — get / set / apply
  ============================================================ */
  function getLogo() {
    return localStorage.getItem(CFG.storageKey) || CFG.defaultLogo;
  }

  function saveLogo(url) {
    url = (url || '').trim();
    if (!url.match(/^https?:\/\//)) {
      toast('URL harus diawali https://', 'err'); return false;
    }
    localStorage.setItem(CFG.storageKey, url);
    applyLogo(url);
    toast('Logo diperbarui!', 'ok');
    return true;
  }

  function resetLogo() {
    localStorage.removeItem(CFG.storageKey);
    applyLogo(CFG.defaultLogo);
    toast('Logo dikembalikan ke default.', 'ok');
  }

  function applyLogo(url) {
    document.querySelectorAll('img.panel-logo, [data-logo-target]').forEach(function (img) {
      img.src = url;
      img.onerror = function () {
        img.src = CFG.defaultLogo;
        img.dataset.error = '1';
      };
    });
  }

  /* ============================================================
     LOGO CHANGER MODAL
  ============================================================ */
  function openLogoModal() {
    if (document.getElementById('tkd-logo-modal')) return;

    var cur = getLogo();
    var modal = document.createElement('div');
    modal.id = 'tkd-logo-modal';
    modal.className = 'modal-bg';
    modal.innerHTML = [
      '<div class="modal-box" style="max-width:440px">',
        '<div class="modal-head">',
          '<span class="modal-title">ɢᴀɴᴛɪ ʟᴏɢᴏ ᴘᴀɴᴇʟ</span>',
          '<button id="tkd-lm-close" style="background:none;border:none;color:var(--t3);cursor:pointer;font-size:16px;line-height:1;padding:2px 6px;border-radius:4px;" onmouseenter="this.style.color=\'var(--t1)\'" onmouseleave="this.style.color=\'var(--t3)\'">&#215;</button>',
        '</div>',
        '<div class="modal-body">',
          '<div class="form-group" style="margin-bottom:10px">',
            '<label>URL Gambar Logo</label>',
            '<input type="url" id="tkd-lm-input" class="form-control" placeholder="https://example.com/logo.png" value="' + cur + '"/>',
            '<div class="field-hint" style="font-size:11px;color:var(--t4);margin-top:4px;font-family:var(--fm)">Gunakan gambar PNG/WebP transparan untuk hasil terbaik.</div>',
          '</div>',
          '<div class="preview-box" id="tkd-lm-preview">',
            '<img src="' + cur + '" alt="preview" style="height:32px;max-width:150px;object-fit:contain;filter:brightness(.95)"/>',
            '<span style="font-size:11px;color:var(--t3);">Preview logo di sidebar</span>',
          '</div>',
        '</div>',
        '<div class="modal-foot">',
          '<button class="btn btn-default btn-sm" id="tkd-lm-reset">Reset Default</button>',
          '<button class="btn btn-primary btn-sm" id="tkd-lm-save">Simpan Logo</button>',
        '</div>',
      '</div>',
    ].join('');

    document.body.appendChild(modal);

    var input   = modal.querySelector('#tkd-lm-input');
    var preview = modal.querySelector('#tkd-lm-preview img');
    var t;

    input.addEventListener('input', function () {
      clearTimeout(t);
      t = setTimeout(function () {
        var v = input.value.trim();
        if (v.match(/^https?:\/\//)) preview.src = v;
      }, 600);
    });

    modal.querySelector('#tkd-lm-save').addEventListener('click', function () {
      if (saveLogo(input.value)) close();
    });

    modal.querySelector('#tkd-lm-reset').addEventListener('click', function () {
      resetLogo();
      input.value = CFG.defaultLogo;
      preview.src = CFG.defaultLogo;
    });

    modal.querySelector('#tkd-lm-close').addEventListener('click', close);

    modal.addEventListener('click', function (e) {
      if (e.target === modal) close();
    });

    document.addEventListener('keydown', escHandler);

    function close() {
      modal.remove();
      document.removeEventListener('keydown', escHandler);
    }

    function escHandler(e) {
      if (e.key === 'Escape') close();
    }
  }

  /* ============================================================
     HAMBURGER / SIDEBAR TOGGLE
  ============================================================ */
  function initHamburger() {
    /* Create hamburger button in topnav if not present */
    var topnav = document.querySelector('#topnav, .topnav, .navbar');
    var sidebar = document.querySelector('#sidebar, .sidebar');
    if (!topnav || !sidebar) return;

    /* Build button */
    var btn = document.createElement('button');
    btn.id = 'hamburger-toggle';
    btn.className = 'hamburger-btn';
    btn.setAttribute('aria-label', 'Toggle sidebar');
    btn.setAttribute('title', 'Toggle menu');
    btn.innerHTML = [
      '<div class="hamburger-icon">',
        '<span></span>',
        '<span></span>',
        '<span></span>',
      '</div>',
    ].join('');

    /* Insert as first child of topnav */
    topnav.insertBefore(btn, topnav.firstChild);

    /* Create overlay */
    var overlay = document.getElementById('sidebar-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'sidebar-overlay';
      document.body.appendChild(overlay);
    }

    /* State */
    var isOpen = window.innerWidth > 900;
    function setOpen(val) {
      isOpen = val;
      document.body.classList.toggle('sidebar-open', isOpen);

      if (window.innerWidth <= 900) {
        sidebar.classList.toggle('is-open', isOpen);
        overlay.classList.toggle('is-open', isOpen);
      } else {
        document.body.classList.toggle('sidebar-collapsed', !isOpen);
      }
    }

    btn.addEventListener('click', function () { setOpen(!isOpen); });
    overlay.addEventListener('click', function () { setOpen(false); });

    /* Close sidebar button inside sidebar */
    var closeBtn = sidebar.querySelector('.sidebar-close-btn');
    if (closeBtn) {
      closeBtn.addEventListener('click', function () { setOpen(false); });
    }

    /* Responsive — reset on resize */
    window.addEventListener('resize', function () {
      if (window.innerWidth > 900) {
        sidebar.classList.remove('is-open');
        overlay.classList.remove('is-open');
        if (document.body.classList.contains('sidebar-open')) {
          document.body.classList.remove('sidebar-collapsed');
        }
      }
    });
  }

  /* ============================================================
     ACTIVE NAV HIGHLIGHT
  ============================================================ */
  function highlightNav() {
    var path = window.location.pathname;
    document.querySelectorAll('#sidebar a[href], .sidebar a[href]').forEach(function (a) {
      var href = a.getAttribute('href');
      if (href && href !== '/' && path.startsWith(href)) {
        a.classList.add('active');
        var li = a.closest('li');
        if (li) li.classList.add('active');
      }
    });
  }

  /* ============================================================
     CONSOLE LABEL
  ============================================================ */
  function patchConsole() {
    var pfx = '%c' + CFG.consoleName;
    var sty = 'color:#636e7a;font-weight:500;font-family:monospace';
    var _l = console.log.bind(console);
    var _w = console.warn.bind(console);
    var _e = console.error.bind(console);
    var _i = console.info.bind(console);
    console.log   = function () { _l.apply(null, [pfx, sty].concat([].slice.call(arguments))); };
    console.warn  = function () { _w.apply(null, [pfx, sty].concat([].slice.call(arguments))); };
    console.error = function () { _e.apply(null, [pfx, sty].concat([].slice.call(arguments))); };
    console.info  = function () { _i.apply(null, [pfx, sty].concat([].slice.call(arguments))); };

    _l('%cTOKOARDAN %ccontainer-tokoardan~%c | dark coal | tokoardan.my.id',
      'color:#a8b0bc;font-weight:600',
      'color:#636e7a;font-family:monospace',
      'color:#3d4650');
  }

  /* ============================================================
     COPYRIGHT FOOTER
  ============================================================ */
  function injectFooter() {
    /* Don't duplicate */
    if (document.querySelector('.tkd-footer')) return;

    var year = new Date().getFullYear();
    var yd   = year > CFG.copyrightStart ? CFG.copyrightStart + '\u2013' + year : CFG.copyrightStart;

    var foot = document.createElement('div');
    foot.className = 'tkd-footer';
    foot.innerHTML = [
      '<span>',
        '<a href="' + CFG.siteUrl + '" target="_blank" rel="noopener">TOKOARDAN</a>',
        ' &mdash; Pterodactyl',
      '</span>',
      '<span>',
        '&copy;' + yd + ' ',
        '<a href="' + CFG.siteUrl + '" target="_blank" rel="noopener">TOKOARDAN</a>',
        ' All Rights Reserved.',
      '</span>',
    ].join('');

    var main = document.getElementById('main')
      || document.querySelector('.main-content')
      || document.body;
    main.appendChild(foot);
  }

  /* ============================================================
     INJECT LOGO CHANGE BUTTON (admin only)
  ============================================================ */
  function injectLogoBtn() {
    var isAdmin = document.querySelector('[data-is-admin]')
      || window.location.pathname.indexOf('/admin') === 0;
    if (!isAdmin) return;

    var nav = document.querySelector('.sidebar-nav, #sidebar nav');
    if (!nav) return;

    var item = document.createElement('a');
    item.href = 'javascript:void(0)';
    item.className = 'nav-link';
    item.style.cssText = 'color:var(--t4);font-size:11.5px;margin-top:6px;';
    item.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg><span>ɢᴀɴᴛɪ ʟᴏɢᴏ</span>';
    item.addEventListener('click', openLogoModal);
    nav.appendChild(item);
  }

  /* ============================================================
     TOAST
  ============================================================ */
  function toast(msg, type) {
    var container = document.getElementById('tkd-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'tkd-toast-container';
      document.body.appendChild(container);
    }

    var el = document.createElement('div');
    el.className = 'tkd-toast ' + (type || '');
    el.textContent = msg;
    container.appendChild(el);

    setTimeout(function () {
      el.style.opacity = '0';
      el.style.transform = 'translateX(10px)';
      el.style.transition = '0.2s ease';
      setTimeout(function () { el.remove(); }, 220);
    }, 2800);
  }

  /* ============================================================
     ENSURE LOGO IS AN IMAGE ELEMENT
     (patches Pterodactyl text-based logo to be an img)
  ============================================================ */
  function patchLogoElement() {
    /* Look for the brand text node Pterodactyl renders */
    var brand = document.querySelector(
      '#sidebar .brand, .sidebar-brand, #sidebar header, .sidebar .header'
    );
    if (!brand) return;

    /* If there's already an img.panel-logo, just update src */
    if (brand.querySelector('img.panel-logo')) {
      applyLogo(getLogo());
      return;
    }

    /* Build image */
    var img = document.createElement('img');
    img.className = 'panel-logo';
    img.alt = 'TOKOARDAN';
    img.src = getLogo();
    img.onerror = function () { img.src = CFG.defaultLogo; };

    /* Wrap in a link */
    var link = document.createElement('a');
    link.href = '/';
    link.className = 'logo-wrap';
    link.appendChild(img);

    /* Hide existing text/logo content and prepend image */
    brand.insertBefore(link, brand.firstChild);
  }

  /* ============================================================
     INIT
  ============================================================ */
  function init() {
    patchConsole();
    patchLogoElement();
    applyLogo(getLogo());
    initHamburger();
    highlightNav();
    injectFooter();
    injectLogoBtn();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  /* Public API */
  window.TokoardanTheme = {
    openLogoModal: openLogoModal,
    setLogo: saveLogo,
    resetLogo: resetLogo,
    toast: toast,
  };

})();
