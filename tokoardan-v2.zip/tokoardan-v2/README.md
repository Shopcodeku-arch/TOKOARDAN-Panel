# TOKOARDAN Theme — Dark Coal Edition
**Custom theme untuk Pterodactyl Panel**
*©2025–2026 [tokoardan.my.id](https://tokoardan.my.id)*

---

## 📁 Struktur File

```
tokoardan-theme/
└── public/
    └── themes/
        └── tokoardan/
            ├── css/
            │   └── theme.css      ← style utama
            └── js/
                └── theme.js       ← hamburger, logo changer, console label
```

---

## 🚀 Cara Install via GitHub

### Langkah 1 — Fork atau Upload ke GitHub

Buka [github.com](https://github.com), buat repository baru.
Contoh nama repo: `tokoardan-theme`

Upload semua file dengan struktur persis seperti di atas.

---

### Langkah 2 — SSH ke VPS

```bash
ssh root@IP_VPS_KAMU
```

---

### Langkah 3 — Masuk ke direktori Pterodactyl

```bash
cd /var/www/pterodactyl
```

---

### Langkah 4 — Buat folder themes

```bash
mkdir -p public/themes/tokoardan/css
mkdir -p public/themes/tokoardan/js
```

---

### Langkah 5 — Download file dari GitHub

Ganti `USERNAME` dan `REPO` sesuai milikmu.

```bash
# Download CSS
curl -fsSL \
  "https://raw.githubusercontent.com/USERNAME/REPO/main/public/themes/tokoardan/css/theme.css" \
  -o public/themes/tokoardan/css/theme.css

# Download JS
curl -fsSL \
  "https://raw.githubusercontent.com/USERNAME/REPO/main/public/themes/tokoardan/js/theme.js" \
  -o public/themes/tokoardan/js/theme.js
```

Atau kalau mau clone seluruh repo:

```bash
git clone https://github.com/USERNAME/REPO.git /tmp/tokoardan-theme
cp -r /tmp/tokoardan-theme/public/themes/tokoardan /var/www/pterodactyl/public/themes/
```

---

### Langkah 6 — Inject CSS & JS ke Pterodactyl

Edit file blade template:

```bash
nano /var/www/pterodactyl/resources/views/layouts/master.blade.php
```

Tambahkan **sebelum `</head>`**:

```html
<link rel="stylesheet" href="/themes/tokoardan/css/theme.css">
```

Tambahkan **sebelum `</body>`**:

```html
<script src="/themes/tokoardan/js/theme.js"></script>
```

Simpan: `Ctrl+X` → `Y` → `Enter`

---

### Langkah 7 — Fix permissions

```bash
chmod -R 755 /var/www/pterodactyl/public/themes/tokoardan
chown -R www-data:www-data /var/www/pterodactyl/public/themes/tokoardan
```

---

### Langkah 8 — Clear cache

```bash
cd /var/www/pterodactyl
php artisan view:clear
php artisan config:clear
php artisan cache:clear
```

---

### Langkah 9 — Restart queue (opsional)

```bash
php artisan queue:restart
```

---

✅ **Selesai.** Buka panel di browser, theme sudah aktif.

---

## 🖼️ Ganti Logo Panel

Logo default sudah diset ke gambar TOKOARDAN.

**Via Admin Panel (direkomendasikan):**
1. Login sebagai admin
2. Di sidebar paling bawah, klik **"ɢᴀɴᴛɪ ʟᴏɢᴏ"**
3. Masukkan URL gambar (PNG/WebP transparan paling bagus)
4. Klik **Simpan Logo**

**Via JavaScript console:**
```js
TokoardanTheme.setLogo('https://example.com/logo.png');
TokoardanTheme.resetLogo(); // kembali ke default
```

---

## 🔄 Update Tema

Kalau kamu update file di GitHub, tinggal pull ulang di VPS:

```bash
cd /tmp/tokoardan-theme
git pull origin main
cp public/themes/tokoardan/css/theme.css /var/www/pterodactyl/public/themes/tokoardan/css/
cp public/themes/tokoardan/js/theme.js   /var/www/pterodactyl/public/themes/tokoardan/js/
cd /var/www/pterodactyl && php artisan view:clear
```

---

## ✨ Fitur

| Fitur | Keterangan |
|-------|-----------|
| **Dark Coal** | Palet hitam arang murni, nol warna hue |
| **Logo Gambar** | Logo sidebar adalah gambar (bukan teks) |
| **Hamburger Menu** | Tombol ☰ di topbar, animasi jadi ✕ |
| **ᴅᴀsʜʙᴏᴀʀᴅ Font Style** | Font kecil kapital via small-caps |
| **Logo Changer** | Ganti logo via URL di admin panel |
| **Console Label** | Prefix `container-tokoardan~` di DevTools |
| **Copyright Footer** | ©2025–2026 TOKOARDAN, link ke tokoardan.my.id |

---

*TOKOARDAN · tokoardan.my.id*
