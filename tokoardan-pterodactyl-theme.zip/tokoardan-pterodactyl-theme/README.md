# 🎮 TOKOARDAN Theme — Pterodactyl Panel

Theme kustom Pterodactyl terinspirasi dari [tokoardan.my.id](https://tokoardan.my.id)

**Warna:** Hitam (`#0f0f0f`) + Gold (`#FACC15`) | **Font:** Poppins | **Style:** Gaming Dark

---

## 📁 Struktur File

```
tokoardan-pterodactyl-theme/
├── css/
│   └── tokoardan.css      ← CSS override utama
├── js/
│   └── tokoardan.js       ← Efek shimmer & branding
└── README.md
```

---

## 🚀 Cara Instalasi di VPS (via GitHub)

### Langkah 1 — Upload ke GitHub

1. Buka [github.com](https://github.com) → login akun kamu
2. Klik **New repository** → beri nama: `tokoardan-ptero-theme`
3. Set ke **Public** → klik **Create repository**
4. Upload semua file ini ke repo tersebut

### Langkah 2 — Login ke VPS

```bash
ssh root@IP_VPS_KAMU
# atau
ssh username@IP_VPS_KAMU
```

### Langkah 3 — Clone theme ke VPS

```bash
cd /tmp
git clone https://github.com/USERNAME_KAMU/tokoardan-ptero-theme.git tokoardan-theme
```
> Ganti `USERNAME_KAMU` dengan username GitHub-mu

### Langkah 4 — Salin file ke direktori Pterodactyl

#### Untuk Panel Pterodactyl (PHP/Bootstrap):

```bash
# Masuk ke direktori panel
cd /var/www/pterodactyl

# Salin CSS ke public
cp /tmp/tokoardan-theme/css/tokoardan.css public/themes/tokoardan.css

# Salin JS ke public
cp /tmp/tokoardan-theme/js/tokoardan.js public/themes/tokoardan.js

# Set permission
chmod 644 public/themes/tokoardan.css
chmod 644 public/themes/tokoardan.js
chown -R www-data:www-data public/themes/
```

#### Untuk Pterodactyl v1.x (React/Modern):

```bash
# CSS ke assets
cp /tmp/tokoardan-theme/css/tokoardan.css /var/www/pterodactyl/public/assets/tokoardan.css

# JS ke assets
cp /tmp/tokoardan-theme/js/tokoardan.js /var/www/pterodactyl/public/assets/tokoardan.js
```

### Langkah 5 — Inject CSS & JS ke layout Pterodactyl

Buka file blade layout utama:

```bash
nano /var/www/pterodactyl/resources/views/layouts/admin.blade.php
```

Tambahkan sebelum tag `</head>`:

```html
<!-- TOKOARDAN THEME -->
<link rel="stylesheet" href="/assets/tokoardan.css">
```

Tambahkan sebelum tag `</body>`:

```html
<!-- TOKOARDAN THEME JS -->
<script src="/assets/tokoardan.js"></script>
```

Simpan: **Ctrl+X → Y → Enter**

---

Lakukan hal yang sama untuk file user layout:

```bash
nano /var/www/pterodactyl/resources/views/layouts/base.blade.php
```

Tambahkan link CSS & JS yang sama seperti di atas.

---

### Langkah 6 — Clear cache Pterodactyl

```bash
cd /var/www/pterodactyl

php artisan view:clear
php artisan config:clear
php artisan cache:clear
php artisan route:clear

# Set permission ulang
chown -R www-data:www-data storage/ bootstrap/cache/
```

### Langkah 7 — Reload nginx/apache

```bash
# Jika pakai nginx:
systemctl reload nginx

# Jika pakai apache:
systemctl reload apache2
```

### Langkah 8 — Verifikasi

Buka browser → kunjungi `dash.tokoardan.my.id` → tekan **Ctrl+Shift+R** untuk force refresh

---

## 🔄 Cara Update Theme (Jika Ada Perubahan)

```bash
# Di VPS, pull update terbaru dari GitHub:
cd /tmp/tokoardan-theme
git pull origin main

# Salin ulang ke direktori panel:
cp css/tokoardan.css /var/www/pterodactyl/public/assets/tokoardan.css
cp js/tokoardan.js /var/www/pterodactyl/public/assets/tokoardan.js

# Clear cache:
cd /var/www/pterodactyl && php artisan view:clear && php artisan cache:clear

# Reload nginx:
systemctl reload nginx
```

---

## ⚠️ Catatan Penting

- Backup dulu sebelum modifikasi file blade:
  ```bash
  cp /var/www/pterodactyl/resources/views/layouts/admin.blade.php admin.blade.php.bak
  cp /var/www/pterodactyl/resources/views/layouts/base.blade.php base.blade.php.bak
  ```
- Jika sudah pakai theme **Nook** sebelumnya, pastikan CSS TOKOARDAN dimuat **setelah** CSS Nook agar override berjalan dengan benar
- Theme ini menggunakan `!important` pada semua override agar kompatibel dengan theme lain

---

## 🎨 Kustomisasi Warna

Edit bagian `:root` di `css/tokoardan.css`:

```css
:root {
  --accent:       #FACC15;   /* ← Ganti warna emas */
  --bg-primary:   #0f0f0f;   /* ← Ganti warna background */
  --bg-secondary: #1a1a1a;   /* ← Ganti warna card */
}
```

---

## 📞 Dukungan

Website: [tokoardan.my.id](https://tokoardan.my.id) | Panel: [dash.tokoardan.my.id](https://dash.tokoardan.my.id)
