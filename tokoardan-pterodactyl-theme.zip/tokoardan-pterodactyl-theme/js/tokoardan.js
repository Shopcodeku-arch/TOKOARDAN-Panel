/**
 * TOKOARDAN Theme - JS Enhancements
 * Efek shimmer, animasi, dan branding khusus TOKOARDAN
 */

(function () {
  'use strict';

  // ===================== SHIMMER LOGO =====================
  // Tambahkan efek shimmer ke logo seperti di tokoardan.my.id
  function applyLogoShimmer() {
    const logos = document.querySelectorAll('.logo, .sidebar-logo, nav img[alt*="logo"], nav img[alt*="Logo"]');
    logos.forEach(logo => {
      const wrapper = logo.parentElement;
      if (wrapper && !wrapper.classList.contains('tokoardan-shimmer-wrapper')) {
        wrapper.classList.add('tokoardan-shimmer-wrapper');
        wrapper.style.cssText += `
          position: relative;
          overflow: hidden;
          display: inline-block;
        `;

        const shimmer = document.createElement('div');
        shimmer.className = 'tokoardan-logo-shimmer';
        shimmer.style.cssText = `
          content: '';
          position: absolute;
          top: 0;
          left: -150%;
          width: 60%;
          height: 100%;
          background: linear-gradient(to right, rgba(255,255,255,0) 0%, rgba(255,255,255,0.4) 50%, rgba(255,255,255,0) 100%);
          transform: skewX(-25deg);
          animation: logo-shimmer 3.5s infinite linear;
          pointer-events: none;
          z-index: 10;
        `;
        wrapper.appendChild(shimmer);

        // Inject keyframe if not exists
        if (!document.getElementById('tokoardan-shimmer-style')) {
          const style = document.createElement('style');
          style.id = 'tokoardan-shimmer-style';
          style.textContent = `
            @keyframes logo-shimmer {
              0%   { left: -150%; }
              100% { left: 200%; }
            }
          `;
          document.head.appendChild(style);
        }
      }
    });
  }

  // ===================== TITLE BRANDING =====================
  // Tambahkan prefix TOKOARDAN ke judul halaman
  function brandPageTitle() {
    const originalTitle = document.title;
    if (!originalTitle.includes('TOKOARDAN')) {
      document.title = 'TOKOARDAN Panel | ' + originalTitle;
    }
  }

  // ===================== STATUS BADGE COLORS =====================
  function enhanceStatusBadges() {
    const statusMap = {
      'running':    { bg: 'rgba(34,197,94,0.15)',  color: '#4ade80',   dot: '#22c55e' },
      'offline':    { bg: 'rgba(239,68,68,0.15)',  color: '#f87171',   dot: '#ef4444' },
      'starting':   { bg: 'rgba(250,204,21,0.12)', color: '#FACC15',   dot: '#FACC15' },
      'stopping':   { bg: 'rgba(249,115,22,0.15)', color: '#fb923c',   dot: '#f97316' },
      'installing': { bg: 'rgba(59,130,246,0.15)', color: '#60a5fa',   dot: '#3b82f6' },
      'suspended':  { bg: 'rgba(124,58,237,0.15)', color: '#a78bfa',   dot: '#7c3aed' },
    };

    Object.entries(statusMap).forEach(([status, style]) => {
      const elements = document.querySelectorAll(
        `[class*="${status}"], [data-status="${status}"], span:contains("${status}")`
      );
      elements.forEach(el => {
        el.style.backgroundColor = style.bg;
        el.style.color = style.color;
        el.style.padding = '3px 10px';
        el.style.borderRadius = '50px';
        el.style.fontWeight = '700';
        el.style.fontSize = '10px';
        el.style.letterSpacing = '0.5px';
        el.style.textTransform = 'uppercase';
      });
    });
  }

  // ===================== SMOOTH TRANSITIONS =====================
  function addSmoothTransitions() {
    const cards = document.querySelectorAll('.box, .card, .panel, [class*="server-"]');
    cards.forEach(card => {
      card.style.transition = 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)';
    });
  }

  // ===================== CONSOLE ENHANCEMENTS =====================
  function enhanceConsole() {
    const consoleEl = document.querySelector('#console, .terminal, [class*="console"]');
    if (!consoleEl) return;

    // Tambahkan label "TOKOARDAN CONSOLE" di atas terminal
    if (!document.getElementById('tokoardan-console-badge')) {
      const badge = document.createElement('div');
      badge.id = 'tokoardan-console-badge';
      badge.innerHTML = '⚡ CONSOLE';
      badge.style.cssText = `
        display: inline-block;
        background: rgba(250, 204, 21, 0.15);
        color: #FACC15;
        font-size: 10px;
        font-weight: 700;
        letter-spacing: 1px;
        padding: 2px 10px;
        border-radius: 50px;
        margin-bottom: 8px;
        border: 1px solid rgba(250,204,21,0.3);
      `;
      consoleEl.parentElement?.insertBefore(badge, consoleEl);
    }
  }

  // ===================== WELCOME TOAST =====================
  function showWelcomeToast() {
    if (sessionStorage.getItem('tokoardan_welcomed')) return;
    sessionStorage.setItem('tokoardan_welcomed', '1');

    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      background: #1a1a1a;
      border: 1px solid rgba(250,204,21,0.4);
      border-radius: 12px;
      padding: 14px 20px;
      display: flex;
      align-items: center;
      gap: 12px;
      z-index: 99999;
      box-shadow: 0 10px 40px rgba(0,0,0,0.8);
      animation: slideInRight 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
      max-width: 300px;
    `;
    toast.innerHTML = `
      <div style="font-size:24px">⚡</div>
      <div>
        <div style="font-weight:700;font-size:13px;color:#fff;font-family:'Poppins',sans-serif">Selamat datang!</div>
        <div style="font-size:11px;color:#FACC15;font-family:'Poppins',sans-serif">TOKOARDAN Game Panel</div>
      </div>
    `;

    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideInRight {
        from { opacity: 0; transform: translateX(60px); }
        to   { opacity: 1; transform: translateX(0); }
      }
      @keyframes slideOutRight {
        from { opacity: 1; transform: translateX(0); }
        to   { opacity: 0; transform: translateX(60px); }
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.style.animation = 'slideOutRight 0.3s ease forwards';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // ===================== INIT =====================
  function init() {
    applyLogoShimmer();
    brandPageTitle();
    addSmoothTransitions();
    enhanceConsole();
    showWelcomeToast();

    // Run on DOM changes (single-page navigation)
    const observer = new MutationObserver(() => {
      applyLogoShimmer();
      enhanceStatusBadges();
      enhanceConsole();
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
